import { Grid } from '@mui/material';
import React from 'react';
import LatexMarkup from './LatexMarkup';
import styles from "../styles/Question.module.css";
import Image from 'next/image';

const Question = ({ question, index }) => {
  return (
    <Grid container>
      <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
        <Grid container className={styles.questionDetails}>
          <Grid item xl={7} lg={6} sm={6} md={7} xs={6}>
            <p className={styles.questionIndex}>Question: {index+1}</p>
          </Grid>
          <Grid item xl={5} lg={6} sm={6} md={5} xs={12}>
            <Grid container>
              <Grid item xl={4} lg={4} sm={6} md={6} xs={6}>
                <span className={styles.questionTypeText}>{question?.mode?.toUpperCase()}</span>
              </Grid>
              <Grid item xl={8} lg={8} sm={6} md={6} xs={6}>
                <span className={styles.positiveMark}>+{Number(question?.markingRule?.positive)?.toFixed(2)}</span>
                <span className={styles.negativeMark}>-{Number(question?.markingRule?.negative)?.toFixed(2)}</span>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
            {
              question?.images?.length ?
                  question?.images?.map((image,i) => (
                      <Image
                        key={i}
                        src={image}
                        alt="question-image"
                        width={400}
                        height={250}
                        className={styles.imageAutoStyle}
                      /> 
                  ))
              : null
            }
          </Grid>
          <Grid item xl={11} lg={11} sm={12} md={12} xs={12}>
            <LatexMarkup
              // className="mb-0"
              latex={question?.text?.en ?? question?.text?.en }
              suppressHydrationWarning
              className={styles.textSize}
            />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  )
}

export default Question;