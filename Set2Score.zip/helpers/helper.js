const PAGINATION_LIMIT = process.env.PAGINATION_LIMIT;

export const validationMessageKey = (apiTag, error) => {
    let key = (error.details[0]?.context.key).toUpperCase();
    let type = error.details[0].type.split(".");
    type = type[1].toUpperCase();
    key = `${apiTag} ${key} ${type} : ${error.details[0].message}`;
    return key;
};

export const getPageAndLimit = (page, limit) => {
    if (!page) page = 1;
    if (!limit) limit = PAGINATION_LIMIT;
    let limitCount = limit * 1;
    let skipCount = (page - 1) * limitCount;
    return { limitCount, skipCount };
};

export const transform = (data) => {
    if(data.filter(item => item.answer === true).length > 1){
        let index = data.reduce((prev, el, i) => { 
            if(el.answer === true) {
                prev.push(getOptionChar(i))
            }
            return prev
        },[]);
        return index.join();
    } else{
        let index = data.findIndex(el => el.answer === true );
        return getOptionChar(index);
    }
};

export const getOptionChar = (index) => {
    switch (index) {
        case 0:
            return 'A'
        case 1:
            return 'B'
        case 2:
            return 'C'
        case 3:
            return 'D'
        default:
            throw new Error('Invalid Choice Index')
    }
};

export const getSelectedAnswerLetter = (choices, selectedAnswer) => {
    let selectedIds = Array.isArray(selectedAnswer) ? selectedAnswer.map(ans => ans._id) : [selectedAnswer._id];
    let selectedOption = [];
    for (let i = 0; i < choices.length; i++) {
        if(selectedIds.includes(choices[i]._id)) {
            selectedOption.push(i);
        }
    }

    if(!selectedOption.length) {
        return null; // no match found
    }else {
        let index = selectedOption.map((val) => getOptionChar(val));
        return index.join();
    }
}

export const formatTime = (time) => {
    const hours = Math.floor(time / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((time % 3600) / 60).toString().padStart(2, '0');
    const seconds = (time % 60).toString().padStart(2, '0');

    return `${hours}:${minutes}:${seconds}`;
};