const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const resultSchema = new Schema({
    user: {
        type: Schema.Types.ObjectId,
        ref: "Student",
    },
    test: {
        type: Schema.Types.ObjectId
    },
    exam: {
        type: Schema.Types.ObjectId,
        ref: "Exam",
    },
    department: {
        type: Schema.Types.ObjectId,
        ref: "Department",
    },
    title: {
        type: Schema.Types.String,
        required: true,
    },
    mode: {
        type: Schema.Types.String,
        required: true,
    },
    totalQuestions: {
        type: Schema.Types.Number,
        required: true,
    },
    answeredQuestions: {
        type: Schema.Types.Number,
        required: true,
    },
    wrongAnswers: {
        type: Schema.Types.Number,
        required: true,
    },
    marksExpected: {
        type: Schema.Types.Number,
        required: true,
    },
    marksObtained: {
        type: Schema.Types.Number,
        required: true,
    },
    marksSubtracted: {
        type: Schema.Types.String,
        required: true,
    },
    scored: {
        type: Schema.Types.String,
        required: true,
    }
},{ collection: 'result', timestamps: true });

if(mongoose.models.Result) {
    module.exports = mongoose.models.Result;
} else {
    module.exports = mongoose.model('Result', resultSchema);
}