import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from 'next-auth/providers/credentials';


const getStudentDetail = async (user) => {
    try {
        let body = { 
            email: user.email,
            fullName: user.name
        };

        const response = await fetch(`${process.env.NEXTAUTH_URL}api/auth/google-signin`,{
            method: 'POST',
            body: JSON.stringify(body)
        })

        let data = await response.json();

        if(data && data?.statusCode == 200) {
            console.log(data,"data");
            return data.data;
        } else {
            console.log(data.message,"error");
            throw new Error(data.message);
        }
    } catch (e) {
        console.log(e,"error");
        throw new Error(e);
    }
}

export default NextAuth({
    secret: process.env.AUTH_SECRET,
    providers: [
        GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
            authorization: {
                params: {
                    prompt: 'consent',
                    access_type: 'offline',
                    response_type: 'code'
                }
            },
        }),
        CredentialsProvider({
            name : "Credentials",
            async authorize(credentials, req){
                let data;
                try {
                    let body = { 
                        email: credentials.email,
                        password: credentials.password
                    };

                    const response = await fetch(`${process.env.NEXTAUTH_URL}api/auth/email-login`,{
                        method: 'POST',
                        body: JSON.stringify(body)
                    })
        
                    data = await response.json();
        
                    if(data && data?.statusCode == 200) {
                        console.log(data,"studentData");
                        return data;
                    } else {
                        console.log(data.message,"error");
                        throw new Error(data.message);
                    }
                } catch (e) {
                    console.log(e,"error");
                    throw new Error(e);
                }
            }
        })
    ],
    callbacks: {
        async signIn({ user, account, profile, email, credentials }) {
            if(account.provider === 'google') {
                user.studentData = await getStudentDetail(user);
            } else {
                user.studentData = user.data
            }
            return true
        },
        async jwt({ token, user }) {
            if (user) {
                token = { 
                    data : user.studentData
                };
            }
            return token
        },
        async session({ session, user, token }) {
            session.studentData = token.data
            return session
        },
    }
})