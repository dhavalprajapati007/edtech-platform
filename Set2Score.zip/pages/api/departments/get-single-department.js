const withMiddleware = require("../middleware");
import { apiError, successapi } from "../../../helpers/responseHelper";
import { fetchExamDepartments } from "../../../services/department.service";
const SUCCESS = process.env.SUCCESS;
const SERVERERROR = process.env.SERVERERROR;
const NOTFOUND = process.env.NO_CONTENT;
const FAILURE = process.env.FAILURE;
const DepartmentModel = require("../../../models/departments");

const getSingleDepartment = async(req, res) => {
    try {
        const { Model } = req.db;
        const reqParam = req.query;

        let department = await Model.findById(reqParam.id);
        if(!department) return apiError(res, "DepartmentDetailNotFound", NOTFOUND);

        return successapi(res, "FetchedDeptDetail", SUCCESS, department);
    }catch (error) {
        console.log('error', error);
        return apiError(res, "SomethingWentWrongPleaseTryAgain", SERVERERROR);
    }
}

export default withMiddleware(getSingleDepartment,DepartmentModel);