const withMiddleware = require("../middleware");
import { apiError, successapi } from "../../../helpers/responseHelper";
const SUCCESS = process.env.SUCCESS;
const SERVERERROR = process.env.SERVERERROR;
const NOTFOUND = process.env.NO_CONTENT;
const FAILURE = process.env.FAILURE;
const ExamModel = require("../../../models/exams");

const getAllExams = async(req, res) => {
    try {
        const { Model } = req.db;

        let exams = await Model.find({});
        if(!exams) return apiError(res, "ExamNotFound", NOTFOUND);

        return successapi(res, "FetchedExamData", SUCCESS, exams);
    }catch (error) {
        console.log('error', error);
        return apiError(res, "SomethingWentWrongPleaseTryAgain", SERVERERROR);
    }
}

export default withMiddleware(getAllExams,ExamModel);