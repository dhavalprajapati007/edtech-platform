const withMiddleware = require("../middleware");
import { apiError, successapi } from "../../../helpers/responseHelper";
import { submitTestResultValidation } from "../../../validations/result.validation";
const SUCCESS = process.env.SUCCESS;
const SERVERERROR = process.env.SERVERERROR;
const NOTFOUND = process.env.NO_CONTENT;
const ResultModel = require("../../../models/result");

const submitTestResult = async(req, res) => {
    try {
        const { Model } = req.db;
        const user = req.user;
        let reqParam = JSON.parse(req.body);

        console.log(user,"---------------------------UserData--------------------");

        if(!user?.department || !user?.exam) {
            return apiError(res,"ExamOrDepartmentNotFound", NOTFOUND);
        }

        // Validate Request
        let validationMessage = await submitTestResultValidation(reqParam);
        if(validationMessage) return apiError(res, validationMessage, SERVERERROR);

        let result = Model({
            user: user._id,
            test: reqParam.test,
            department: reqParam.department,
            exam: reqParam.exam,
            mode: reqParam.mode,
            title: reqParam.title,
            totalQuestions: reqParam.totalQuestions,
            answeredQuestions: reqParam.answeredQuestions,
            wrongAnswers: reqParam.wrongAnswers,
            marksExpected: reqParam.marksExpected,
            marksObtained: reqParam.marksObtained,
            marksSubtracted: reqParam.marksSubtracted,
            scored: reqParam.scored,
        });

        let savedResult = await result.save();

        return successapi(res, "ResultDataSubmitedSuccessFully", SUCCESS, savedResult);
    }catch (error) {
        console.log('error', error);
        return apiError(res, "SomethingWentWrongPleaseTryAgain", SERVERERROR);
    }
}

export default withMiddleware(submitTestResult,ResultModel);