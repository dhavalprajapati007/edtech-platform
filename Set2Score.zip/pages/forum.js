import Head from 'next/head';
import React from 'react'

const Forum = () => {
    return (
        <>
            <Head>
                <title>Set2Score-Forum</title>
                <meta name="description" content="Skyrocket your presentation for gate exam" />
                <meta name="keywords" content="gate, set2score, engineering" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="icon" href="/favicon.png" />
            </Head>
            <section>
                <h1>Forum</h1>
            </section>
        </>
    )
}

export default Forum;