import { Button, Divider, Grid } from '@mui/material';
import { getSession } from 'next-auth/react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react'
import { handleLogut } from '../utils/logout';
import styles from "../styles/Instruction.module.css"
import Link from 'next/link';
import SelectSubject from '../components/Modal/SelectSubject';
import LatexMarkup from '../components/LatexMarkup';
import Loader from '../components/Loader';
import { toastAlert } from '../helpers/toastAlert';

const Instruction = ({ session }) => {
    const [data, setData] = useState({});
    const [loading, setLoading] = useState(false);
    const [optionalSections, setOptionalSections] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedSections, setSelectedSections] = useState([]);
    const router = useRouter();
    const { id, section } = router.query;

    useEffect(() => {
        setLoading(true);
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            let body = {
                id
            };

            let URL;
            if(section === "pastPapers") {
                URL = '/api/previousPapers/get-single-paper';
            }else {
                URL = '/api/testSeries/get-single-test-series';
            }

            const response = await fetch(URL, {
                method: "POST",
                body : JSON.stringify(body),
                headers: { 'Authorization': session?.studentData?.accessToken }
            });
            const data = await response.json();
            if(data && data?.statusCode == 200) {
                console.log(data,"testData");
                setData(Object.keys(data?.data).length ? data?.data : []);
                setLoading(false);
            } else {
                if(data.statusCode == 401) {
                    handleLogut(router);
                }
                setLoading(false);
                toastAlert(data.message,"error");
                console.log(data.message,"errorInFetchTestData");                  
            }
        } catch(e) {
            setLoading(false);
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
            console.log(e,"errorInCatchBlock");
        }
    };

    const redirect = () => {
        router.push({
            pathname: '/pastPapers/testMode',
            query: { id }
        })
    };

    const redirectToTestSeries = () => {
        router.push({
            pathname: '/testSeries/testMode',
            query: { id }
        })
    };

    const handleNextClick = async() => {
        if(section === "testSeries") {
            redirectToTestSeries();
        }else {
            if(!data?.selectSection) {            
                redirect();
            }else {
                let optionalSections = await data.sections?.filter((section) => section.compulsory === "No");
                if(optionalSections.length) {
                    setOptionalSections(optionalSections);
                    setShowModal(true);
                }else {
                    redirect();
                }
            }
        }
    }

    const handleModalClose = () => {
        setShowModal(false);
    }

    const handleSectionSelect = async(value) => {
        if(!selectedSections?.length) {
            let arr = [];
            arr.push(value);
            setSelectedSections(arr);
        } else {
            if(selectedSections.some(data => data._id === value._id)) {
                setSelectedSections(selectedSections.filter((data => data._id !== value._id)));
            }else {
                if(selectedSections.length < data.selectSection) {
                    let updatedData = [...selectedSections];
                    updatedData.push(value);
                    setSelectedSections(updatedData);
                }
            }
        }
    }

    return (
        <div>
            <Head>
                <title>Set2Score-Instruction</title>
                <meta name="description" content="Skyrocket your presentation for gate exam" />
                <meta name="keywords" content="gate, set2score, engineering" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="icon" href="/favicon.png" />
            </Head>
            <section>
                <Grid container className={styles.mainContainer}>
                    {
                        loading ?
                            <Grid container>
                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                    <Loader/>
                                </Grid>
                            </Grid>
                        :
                            <Grid container>
                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                    <Grid container>
                                        <Grid item xl={9} lg={9} sm={9} md={9} xs={9} className={styles.instructionsSection}>
                                            <Grid container>
                                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                    <Grid container>
                                                        <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                            <p className={styles.instructionTitle}>Instructions</p>
                                                        </Grid>
                                                    </Grid>

                                                    <Grid container>
                                                        <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.instructionsContainer}>
                                                            <LatexMarkup
                                                                latex={data?.instructions?.en ?? data?.instructions?.en }
                                                                suppressHydrationWarning
                                                                className={styles.marginRight}
                                                            />
                                                        </Grid>
                                                    </Grid>

                                                    <Grid container>
                                                        <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.backAndNextBtnContainer}>
                                                            <Grid container>
                                                                <Grid item xl={6} lg={6} sm={6} md={6} xs={6}>
                                                                    <Link
                                                                        href={{ 
                                                                            pathname: `/${section}`,
                                                                        }}
                                                                    >
                                                                        <Button
                                                                            className={styles.backBtn}
                                                                        >
                                                                            Back
                                                                        </Button>
                                                                    </Link>
                                                                </Grid>
                                                                <Grid item xl={6} lg={6} sm={6} md={6} xs={6} className={styles.nextBtnGrid}>
                                                                    <Button
                                                                        className={styles.nextBtn}
                                                                        onClick={() => handleNextClick()}
                                                                    >
                                                                        Next
                                                                    </Button>
                                                                </Grid>

                                                                {
                                                                    showModal ?
                                                                        <Grid container>
                                                                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                                                <SelectSubject 
                                                                                    open={showModal}
                                                                                    handleClose={handleModalClose}
                                                                                    data={optionalSections}
                                                                                    handleSectionSelect={handleSectionSelect}
                                                                                    selectedSections={selectedSections}
                                                                                    totalSelectSection={data.selectSection}
                                                                                />
                                                                            </Grid>
                                                                        </Grid>
                                                                    : null
                                                                }
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>

                                        <Grid item xl={3} lg={3} sm={3} md={3} xs={3}>
                                            <Grid container>
                                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                    <Grid container>
                                                        <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.testDetailsContainer}>
                                                            <p>Name of the test: {data?.name?.en}</p>
                                                            <p>Duration of test: {data.time}</p>
                                                            <p>No. of questions: {data?.sections?.flatMap(section => section.questions).length}</p>
                                                            <p>Total Marks: {data.marks}</p>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                    }
                </Grid>
            </section>
        </div>
    )
}

export default Instruction;

export async function getServerSideProps(context) {
    const { req } = context;
    const session = await getSession({ req });
    
    if(!session) {
        return {
            redirect: { destination: "/" },
        };
    }
      
    return {
        props: {
            session
        }
    }
}