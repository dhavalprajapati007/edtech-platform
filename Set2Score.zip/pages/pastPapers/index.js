import { Button, Grid, Paper } from '@mui/material';
import { getSession } from 'next-auth/react';
import Head from 'next/head';
import React, { useEffect, useState } from 'react';
import Footer from '../../components/Footer';
import GetTheApp from '../../components/GetTheApp';
import NavigationMenu from '../../components/NavigationMenu';
import styles from "../../styles/PastPapers.module.css";
import FeatureSlider from '../../components/FeatureSlider';
import LinkSection from '../../components/LinkSection';
import SocialMediaIcons from '../../components/SocialMediaIcons';
import LockIcon from "../../public/assets/images/Locked.png";
import UnlockIcon from "../../public/assets/images/Unlocked.png";
import Image from 'next/image';
import { useRouter } from 'next/router';
import { handleLogut } from '../../utils/logout';
import Loader from '../../components/Loader';
import { toastAlert } from '../../helpers/toastAlert';

const PastPapers = ({ session }) => {
    const [activeTabs, setActiveTabs] = useState("full");
    const [storeData, setStoreData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([]);
    const router = useRouter();

    const handleClick = (id) => {
        router.push({
            pathname: '/pastPapers/fullMode',
            query: { id, mode : activeTabs },
        })
    }

    useEffect(() => {
        setLoading(true);
        getFullLengthPapers();
        fetchStoreData();
    },[]);

    const getFullLengthPapers = async () => {
        try {
            let URL = "/api/previousPapers/get-full-length-papers";

            const response = await fetch(URL, {
                method: "GET",
                headers: { 'Authorization': session?.studentData?.accessToken }
            });

            const data = await response.json();

            if(data && data?.statusCode == 200) {
                console.log(data,"storeData");
                setData(data.data?.length ? data.data : []);
                setLoading(false);
            } else {
                if(data.statusCode == 401) {
                    handleLogut(router);
                }
                setLoading(false);
                console.log(data.message,"error");
                toastAlert(data.message,"error");
            }
        } catch (e) {
            setLoading(false);
            console.log(e,"error");
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
        }
    };

    const getSubjectWisePapers = async () => {
        try {
            let URL = "/api/previousPapers/get-department-wise-subjects";

            const response = await fetch(URL, {
                method: "GET",
                headers: { 'Authorization': session?.studentData.accessToken }
            });

            const data = await response.json();

            if(data && data?.statusCode == 200) {
                setLoading(false);
                console.log(data,"storeData");
                setData(data.data?.length ? data.data : []);
            } else {
                if(data.statusCode == 401) {
                    handleLogut(router);
                }
                setLoading(false);
                console.log(data.message,"error");
                toastAlert(data.message,"error");
            }
        } catch (e) {
            setLoading(false);
            console.log(e,"error");
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
        }
    };

    const fetchStoreData = async () => {
        try {
            let URL = "/api/payments/get-previous-year-paper-payments";

            const response = await fetch(URL, {
                method: "GET",
                headers: { 'Authorization': session.studentData.accessToken }
            });

            const data = await response.json();

            if(data && data?.statusCode == 200) {
                console.log(data,"storeData");
                setStoreData(data.data?.length ? data.data : []);
            } else {
                if(data.statusCode == 401) {
                    handleLogut(router);
                }
                toastAlert(data.message,"error");
                console.log(data.message,"error");
            }
        } catch(e) {
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
            console.log(e,"error");
        }
    };

    const handleTabChange = (val) => {
        if(activeTabs !== val) {
            setActiveTabs(val);
            setLoading(true);
            if(val==="full") {
                getFullLengthPapers();
            }else {
                getSubjectWisePapers();
            }
        }
    }

    return (
        <>
            <Head>
                <title>Set2Score-PastPapers</title>
                <meta name="description" content="Skyrocket your presentation for gate exam" />
                <meta name="keywords" content="gate, set2score, engineering" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="icon" href="/favicon.png" />
            </Head>
            <section>
                {
                    loading ?
                        <Grid container className={styles.marginSpace}>
                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                <Loader/>
                            </Grid>
                        </Grid>
                    :
                        <Grid container className={styles.homePageContainer}>
                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.marginSpace}>
                                <NavigationMenu />
                            </Grid>
                            
                            {/* ABOUT_DEPARTMENT_SECTION: START */}
                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.marginSpace}>
                                <Grid container spacing={1}>
                                    <Grid item xl={8} lg={8} md={12} sm={12} xs={12}>
                                        <Grid container className={styles.sectionTabs}>
                                            <Grid item xl={6} lg={6} md={6} sm={6} xs={6}>
                                                <span 
                                                    onClick={() => handleTabChange("full")}
                                                    className={`${activeTabs === "full" ? styles.active : ""} ${styles.headerStyle}`}
                                                >
                                                    Full Length
                                                </span>
                                            </Grid>
                                            <Grid item xl={6} lg={6} md={6} sm={6} xs={6}>
                                                <span
                                                    onClick={() => handleTabChange("subject")}
                                                    className={`${activeTabs === "subject" ? styles.active : ""} ${styles.headerStyle}`}
                                                >
                                                    Subject Wise
                                                </span>
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            {
                                                (activeTabs === "full" && data?.length) ?
                                                    data?.map((paper,idx) => (
                                                        <Grid item xl={6} lg={6} md={6} sm={6} xs={12} className={styles.paperListSection} key={idx}>
                                                            <Grid container className={styles.paperSection}>
                                                                <Grid item xl={8} lg={8} sm={8} md={8} xs={6} className={styles.paperTitle}>
                                                                    <p onClick={() => !paper.lock && handleClick(paper._id)}>{paper?.name?.en}</p>
                                                                </Grid>
                                                                <Grid item xl={3} lg={3} sm={3} md={3} xs={6} className={styles.btnSection}>
                                                                    <Button 
                                                                        className={paper.lock ? styles.lockButton : styles.unlockButton}
                                                                        disabled={paper.lock}
                                                                        onClick={() => handleClick(paper._id)}
                                                                    >
                                                                        <Image src={paper.lock ? LockIcon : UnlockIcon} alt="lockIcon"/>
                                                                        { paper.lock ? "Locked" : "Free" }
                                                                    </Button>
                                                                </Grid>
                                                            </Grid>
                                                        </Grid>
                                                    ))
                                                :
                                                    (activeTabs === "subject" && data?.length && data[0]?.subjects?.length) ?
                                                        data[0]?.subjects?.map((subject,idx) => (
                                                            <Grid item xl={6} lg={6} sm={6} md={6} xs={12} className={styles.paperListSection} key={idx}>
                                                                <Grid container className={styles.paperSection}>
                                                                    <Grid item xl={8} lg={8} sm={8} md={8} xs={6} className={styles.paperTitle}>
                                                                        <p onClick={() => !subject.lock && handleClick(subject._id)}>{subject?.title}</p>
                                                                    </Grid>
                                                                    <Grid item xl={3} lg={3} sm={3} md={3} xs={6} className={styles.btnSection}>
                                                                        <Button
                                                                            className={subject.lock ? styles.lockButton : styles.unlockButton}
                                                                            disabled={subject.lock}
                                                                            onClick={() => handleClick(subject._id)}
                                                                        >
                                                                            <Image src={subject.lock ? LockIcon : UnlockIcon} alt="lockIcon"/>
                                                                            { subject.lock ? "Locked" : "Free" }
                                                                        </Button>
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        ))
                                                : null
                                            }
                                        </Grid>
                                    </Grid>
                                    <Grid item xl={4} lg={4} md={12} sm={12} xs={12} className={styles.rightSection}>
                                        <Grid container>
                                            <Grid item xl={6} lg={2} md={4} sm={3} xs={0}></Grid>
                                            <Grid item xl={4} lg={8} md={6} sm={7} xs={10} className={styles.linkSection}>
                                                <LinkSection/>
                                            </Grid>
                                            <Grid item xl={2} lg={2} md={2} sm={2} xs={2} className={styles.socialMediaIconsContainer}>
                                                <SocialMediaIcons />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                            {/* ABOUT_DEPARTMENT_SECTION: END */}

                            {/* FEATURE_SECTION: START */}
                            <Grid item xl={12} lg={12} md={12} sm={12} xs={12} className={styles.previousPapersSliderSection}>
                                <Grid container>
                                    <Grid item xl={1} lg={1} md={0} sm={0} xs={0}></Grid>
                                    <Grid item xl={10} lg={10} md={12} sm={12} xs={12}>
                                        <Grid container spacing={2}>
                                            <Grid item xl={12} lg={12} md={12} sm={12} xs={12} className={styles.previousPapersHeading}>
                                                <h2>Our <span className={styles.previousPapersTextStyle}>Previous year papers ?</span></h2>
                                            </Grid>
                                            <Grid item xl={12} lg={12} md={12} sm={12} xs={12}>
                                                <FeatureSlider
                                                    type={"store"}
                                                    data={storeData}
                                                />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                    <Grid item xl={1} lg={1} md={0} sm={0} xs={0}></Grid>
                                </Grid>
                            </Grid>
                            {/* FEATURE_SECTION: END */}

                            {/* GET_THE_APP_SECTION: START */}
                            <Grid container>
                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                    <GetTheApp/>
                                </Grid>
                            </Grid>
                            {/* GET_THE_APP_SECTION: END */}

                            {/* FOOTER_SECTION: START */}
                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={`${styles.footerSection} ${styles.marginSpace}`}>
                                <section id="contact">
                                    <Footer />
                                </section>
                            </Grid>
                            {/* FOOTER_SECTION: END */}
                        </Grid>
                }
            </section>
        </>
    )
}

export default PastPapers;

export async function getServerSideProps(context) {
    const { req } = context;
    const session = await getSession({ req });
    
    // change this condition to !session later
    if(!session) {
        return {
            redirect: { destination: "/" },
        };
    }
      
    return {
        props: { session }
    }
}