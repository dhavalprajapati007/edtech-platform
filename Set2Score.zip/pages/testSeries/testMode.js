import { Button, CircularProgress, Grid, Typography } from '@mui/material';
import { getSession } from 'next-auth/react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import AnswerInput from '../../components/AnswerInput';
import Choices from '../../components/Choices';
import Instruction from '../../components/Modal/Instruction';
import QuestionPaper from '../../components/Modal/QuestionPaper';
import Question from '../../components/Question';
import styles from "../../styles/TestMode.module.css";
import { handleLogut } from '../../utils/logout';
import Calc from "../../public/assets/images/TestModeCalc.png";
import ScreenMode from "../../public/assets/images/ScreenMode.png"
import ExclamationIcon from "../../public/assets/images/circleAlertIcon.png"
import TestModeTimer from "../../public/assets/images/TestModeTimer.png"
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import MuiAccordion from '@mui/material/Accordion';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Draggable from 'react-draggable';
import ScientificCalculator from '../../components/ScientificCalculator';
import CountdownTimer from '../../components/Timer';
import CustomText from '../../components/Modal/CustomText';
import SubmiTestConfirmation from '../../components/Modal/SubmiTestConfirmation';
import Loader from '../../components/Loader';
import scrollBarStyles from "../../styles/Scrollbar.module.css";
import { toastAlert } from '../../helpers/toastAlert';

const Accordion = styled((props) => (
    <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    border: `1px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
        borderBottom: 0,
    },
    '&:before': {
        display: 'none',
    },
}));
  
const AccordionSummary = styled((props) => (
    <MuiAccordionSummary
        {...props}
    />
))(({ theme }) => ({
    backgroundColor:
    theme.palette.mode === 'dark'
    ? 'rgba(255, 255, 255, .05)'
    : 'rgba(0, 0, 0, .03)',
    flexDirection: 'row-reverse',
    '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
        transform: 'rotate(90deg)',
    },
    '& .MuiAccordionSummary-content': {
        marginLeft: theme.spacing(1),
    },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
    padding: theme.spacing(2),
    borderTop: '1px solid rgba(0, 0, 0, .125)',
}));

const TestMode = ({ session }) => {
    const [showInstruction, setShowInstruction] = useState(false);
    const [showQuestionPaper, setShowQuestionPaper] = useState(false);
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState({});
    const [userActionData, setUserActionData] = useState([]);
    const [questionsList, setQuestionsList] = useState([]);
    const [currentQuestion, setCurrentQuestion] = useState({});
    const [currentIndex, setCurrentIndex] = useState(0);
    const [expanded, setExpanded] = React.useState('panel0');
    const [activeSection, setActiveSection] = useState(0);
    const [showCalculator, setShowCalculator] = useState(false);
    const [showCustomTextModal, setShowCustomTextModal] = useState(false);
    const [showSubmitTestConfirmationModal, setShowSubmitTestConfirmationModal] = useState(false);
    const [submitTestLoader, setSubmitTestLoader] = useState(false);
    const [remainingTime, setRemainingTime] = useState(null);
    const router = useRouter();
    const { id } = router.query;

    useEffect(() => {
        setLoading(true);
        fetchTestSeriesPaper();
    }, []);

    const fetchTestSeriesPaper = async () => {
        try {
            localStorage.removeItem("userActionData");
            localStorage.removeItem("remainingTime");
            let body = {
                id
            };

            const response = await fetch('/api/testSeries/get-single-test-series', {
                method: "POST",
                body : JSON.stringify(body),
                headers: { 'Authorization': session?.studentData?.accessToken }
            });
            const data = await response.json();
            if(data && data?.statusCode == 200) {
                console.log(data,"singlePaperData");
                setData(Object.keys(data?.data).length ? data?.data : []);
                const allQuestions = data?.data?.sections?.flatMap(section => section.questions);
                setQuestionsList(allQuestions);
                setCurrentQuestion(allQuestions[0]);
                setActiveSection(0);
                setCurrentIndex(0);
                const initialUserActionData = await allQuestions?.map((question,i) => ({
                    id: question._id,
                    answer: "",
                    result: "",
                    actualMarks: parseFloat(question.markingRule?.positive),
                    obtainedMarks: 0, 
                    status: i === 0 ? "notAnswered" : "notVisited"
                }));
                setUserActionData(initialUserActionData);
                setLoading(false);
            } else {
                if(data.statusCode == 401) {
                    handleLogut(router);
                }
                setLoading(false);
                console.log(data.message,"errorInFullPaperLoad");
                toastAlert(data.message,"error");
            }
        } catch(e) {
            setLoading(false);
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
            console.log(e,"errorInCatchBlock");
        }
    };

    useEffect(() => {
        if(remainingTime === 0) {
            setShowCustomTextModal(true);
            handleSectionTackle();
        }
    }, [remainingTime]);

    const handleModalClose = () => {
        setShowQuestionPaper(false);
    }

    const handleConfirmationModalClose = () => {
        setShowSubmitTestConfirmationModal(false);
    }

    const handleTimeUpModalClose = () => {
        setShowCustomTextModal(false);
    }

    const handleInstructionModalClose = () => {
        setShowInstruction(false);
    }

    const handleMCQAnswerSelect = async(event,id) => {
        const newUserActionData = [...userActionData];
        let question = await questionsList.find((ques) => ques._id === id);
        let choiceAns = await question?.choices?.find((choice) => choice?._id === event.target.value);
        let specificData = await newUserActionData?.find((act) => act.id === id);
        specificData.answer = choiceAns;
        specificData.result = choiceAns?.answer;
        specificData.obtainedMarks = choiceAns?.answer ? parseFloat(question?.markingRule?.positive) : parseFloat(question?.markingRule?.negative);
        setUserActionData(newUserActionData);
    };

    const handleMSQAnswerSelect = async(choice,id) => {
        const newUserActionData = [...userActionData];
        let specificData = await newUserActionData?.find((act) => act.id === id);
        if(!specificData?.answer?.length) {
            let arr = [];
            arr.push(choice);
            specificData.answer = arr
        } else {
            if(specificData.answer.some(obj => obj._id === choice._id)) {
                specificData.answer = specificData.answer.filter((obj => obj._id !== choice._id))
            }else {
                specificData.answer.push(choice);
            }
        }

        if(specificData.answer?.length) {
            let { result, marks } = await checkMSQAnswer(currentQuestion.choices,specificData.answer);
            specificData.result = result;
            specificData.obtainedMarks = marks;
        }else {
            specificData.result = "";
            specificData.obtainedMarks = 0;
        }
        setUserActionData(newUserActionData);
    }

    const checkMSQAnswer = async(choices, selectedOptions) => {
        const correctAnswerIds = new Set(choices.filter(choice => choice.answer).map(choice => choice._id));
        const selectedIds = new Set(selectedOptions.map(option => option._id));
        if(selectedOptions.some((option) => option.answer === false)) {
            return { result : false, marks : Number(currentQuestion.markingRule.negative) };
        }else {
            const isCorrect = correctAnswerIds.size === selectedIds.size && [...correctAnswerIds].every(id => selectedIds.has(id));
            if(isCorrect) {
                return { result : isCorrect, marks : Number(currentQuestion.markingRule.positive)};
            }else {
                return { result : isCorrect, marks : 0};
            }
        }
    }

    const handleAnswerValue = async(value,id) => {
        setUserActionData(prevState => {
            const newState = [...prevState];
            const arrIndex = newState.findIndex(obj => obj.id === id);
            newState[arrIndex] = { ...newState[arrIndex], answer: value, result : ""};
            return newState;
        });
    }

    const handleAccordionChange = (panel,idx) => (event, newExpanded) => {
        setExpanded(newExpanded ? panel : false);
    };

    const handleQuestionIndexClick = async(sectionId,questionId, id) => {
        setActiveSection(sectionId);
        setCurrentIndex(questionId);
        setCurrentQuestion(questionsList?.find((que) => que?._id === id));
        const newUserActionData = [...userActionData];
        let specificData = await newUserActionData?.find((act) => act.id === id);
        if(specificData.status === "notVisited") {
            specificData.status = "notAnswered";
        }
        setUserActionData(newUserActionData);
    }

    const clearResponse = async() => {
        const newUserActionData = [...userActionData];
        let specificData = await newUserActionData?.find((act) => act.id === currentQuestion._id);
        specificData.answer = "";
        specificData.result = "";
        specificData.obtainedMarks = 0;
        setUserActionData(newUserActionData);
    }

    const handleNavigate = async() => {
        let questionIndex = await questionsList.findIndex((ques) => ques._id === currentQuestion._id);
        if(data.sections[activeSection].questions.length === currentIndex+1 && data.sections.length !== activeSection+1) {
            setActiveSection(activeSection+1);
            setExpanded(`panel${activeSection+1}`);
            setCurrentIndex(0);
            setCurrentQuestion(questionsList[questionIndex+1]);
        }else{
            if(!(data.sections.length === activeSection+1 && data.sections[activeSection].questions.length === currentIndex+1)) {
                setCurrentIndex(currentIndex+1);
                setCurrentQuestion(questionsList[questionIndex+1]);
            }
        }
    }

    const saveAndNext = async() => {
        const newUserActionData = [...userActionData];
        let specificData = await newUserActionData?.find((act) => act.id === currentQuestion._id);

        if(specificData.answer === "") {
            specificData.status = "notAnswered"
        }else {
            specificData.status = "answered"
        };
        await handleNavigate();
        currentQuestion.mode === "answer" && await checkAnswer();
        setUserActionData(newUserActionData);
    }

    const markForReview = async() => {
        const newUserActionData = [...userActionData];
        let specificData = await newUserActionData?.find((act) => act.id === currentQuestion._id);
        if(specificData.answer === "") {
            specificData.status = "marked"
        }else {
            specificData.status = "markedAndAnswered"
        };
        await handleNavigate();
        currentQuestion.mode === "answer" && await checkAnswer();
        setUserActionData(newUserActionData);
    }

    const handleTimeChange = (value) => {
        setRemainingTime(value);
    };

    const checkAnswer = () => {
        let newUserActionData = [...userActionData];
        const specificData = newUserActionData.find(obj => obj.id === currentQuestion._id);
        let answer = currentQuestion?.answer?.en;
        let value = Number(specificData.answer);
        const t = answer.indexOf(",");
        if (t != -1) {
            //two range answer
            //Divide it into 2 parts 
            let splitAns = answer.split(",");
            const answer1 = splitAns[0].split("to");
            //answer1 is first range
            const answer2 = splitAns[1].split("to");
            // answer2 is second range
            if((Number(answer1[0]) <= value && value <= Number(answer1[1])) ||  (Number(answer2[0]) <= value && value <= Number(answer2[1]))) {
                specificData.result = true;
                specificData.obtainedMarks = Number(currentQuestion.markingRule.positive);
                setUserActionData(newUserActionData);
            } else {
                specificData.result = false;
                specificData.obtainedMarks = Number(currentQuestion.markingRule.negative);
                setUserActionData(newUserActionData);
            }
        } else {
            // One Range
            const check = answer.indexOf("to");
            if(check!=-1) {
                let myna = answer.split("to");
                if(Number(myna[0]) <= value && value <= Number(myna[1])){
                    specificData.result = true;
                    specificData.obtainedMarks = Number(currentQuestion.markingRule.positive);
                    setUserActionData(newUserActionData);
                } else {
                    specificData.result = false;
                    specificData.obtainedMarks = Number(currentQuestion.markingRule.negative);
                    setUserActionData(newUserActionData);
                }
            } else {
                //only one answer
                if(Number(answer) == value){
                    specificData.result = true;
                    setUserActionData(newUserActionData);
                }else{
                    specificData.result = false;
                    setUserActionData(newUserActionData);
                }
            }
        }
    }

    const handlePaperSubmit = () => {
        setShowSubmitTestConfirmationModal(true);
    }

    const handleCalcClose = () => {
        setShowCalculator(false);
    }

    const submitPaper = async (result) => {
        setSubmitTestLoader(true);
        // call API to store results in database
        try {
            let answered = result?.filter((action) => action?.status === "answered" || action?.status === "markedAndAnswered");
            let marksObtained = answered.reduce((acc, val) => val.result ? acc + val.obtainedMarks : acc, 0); 
            let marksSubtracted = answered.reduce((acc, val) => !val.result ? acc + val.obtainedMarks : acc, 0);

            let URL = "/api/result/store-test-result-data";
            let body = {
                test: data._id,
                department: data.department,
                exam: data.exam ,
                mode: "testSeries",
                title: data?.name?.en,
                totalQuestions: result?.length,
                answeredQuestions: answered.length,
                wrongAnswers: answered?.filter((action) => action?.result === false).length,
                marksExpected: answered.reduce((acc, val) => acc + val.actualMarks, 0),
                marksObtained,
                marksSubtracted: marksSubtracted.toFixed(2),
                scored: (marksObtained - marksSubtracted).toFixed(2),
            };

            console.log(body,"payloadForSubmitTest");

            const response = await fetch(URL, {
                method: "POST",
                body : JSON.stringify(body),
                headers: { 'Authorization': session?.studentData?.accessToken }
            });

            const responseData = await response.json();

            if(responseData && responseData?.statusCode == 200) {
                setSubmitTestLoader(false);
                console.log(responseData,"submitTestData");
                await localStorage.setItem("userActionData",JSON.stringify(result));
                await localStorage.setItem("remainingTime",JSON.stringify(remainingTime));
                await sessionStorage.removeItem('countdownTimer');
                toastAlert(responseData.message,"success");
                router.push({
                    pathname: '/scoreCard',
                    query: { id, section : "testSeries" }
                })
            } else {
                if(responseData.statusCode == 401) {
                    handleLogut(router);
                }
                setSubmitTestLoader(false);
                toastAlert(responseData.message,"error");
                console.log(responseData.message,"error");
            }
        } catch(e) {
            setSubmitTestLoader(false);
            console.log(e,"error");
            toastAlert("Something Went Wrong, Please Try Again After Sometime","error");
        }
    }

    const handleSectionTackle = async() => {
        let finalArr = [];
        data?.sections?.map((section) => {
            let firstIndex = userActionData.findIndex((ques) => ques.id === section.questions[0]._id);
            let lastIndex = userActionData.findIndex((ques) => ques.id === section.questions[section.questions.length-1]._id);

            let slicedArr = userActionData.slice(firstIndex,lastIndex+1);
            if(section.tackle > 0) {
                let filteredArr = slicedArr?.filter((action) => action?.status === "answered" || action?.status === "markedAndAnswered");
                let tackledArr = filteredArr.slice(0,section.tackle);
                finalArr.push(tackledArr);
            } else {
                finalArr.push(slicedArr);
            }
        })

        if(data?.sections.some((section) => section.tackle > 0)) {
            submitPaper(finalArr.flat());
        }else {
            submitPaper(userActionData);
        }
    };

    return (
        <>
            <Head>
                <title>Set2Score-TestMode</title>
                <meta name="description" content="Skyrocket your presentation for gate exam" />
                <meta name="keywords" content="gate, set2score, engineering" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="icon" href="/favicon.png" />
            </Head>
            <section>
                <Grid container className={styles.mainContainer}>
                    {
                        loading ?
                            <Grid container>
                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                    <Loader/>
                                </Grid>
                            </Grid>
                        :
                            <Grid container>
                                <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                    <Grid container className={styles.titleAndTimerContainer}>
                                        <Grid item xl={7} lg={6} md={4} sm={3} xs={12}>
                                            <p className={styles.testTitle}>{data?.name?.en?.length ? data?.name?.en : ""}</p>
                                        </Grid>
                                        <Grid item xl={5} lg={6} md={8} sm={9} xs={12}>
                                            <Grid container>
                                                <Grid item xl={1} lg={1} md={1} sm={1} xs={4} className={styles.centerAndEndPlacement}>
                                                    <Image
                                                        src={Calc}
                                                        className={styles.actionIcon}
                                                        alt="calcIcon"
                                                        onClick={() => setShowCalculator(!showCalculator)}
                                                    />
                                                </Grid>
                                                <Grid item xl={1} lg={1} md={1} sm={1} xs={4} className={styles.centerAndEndPlacement}>
                                                    <Image src={ScreenMode} className={styles.actionIcon} alt="screenModeIcon"/>
                                                </Grid>
                                                <Grid item xl={1} lg={1} md={1} sm={1} xs={4} className={styles.centerAndEndPlacement}>
                                                    <Image
                                                        src={ExclamationIcon}
                                                        className={styles.actionIcon}
                                                        alt="screenModeIcon"
                                                        onClick={() => setShowInstruction(true)}
                                                    />
                                                    {
                                                        showInstruction ?
                                                            <Instruction
                                                                open={showInstruction}
                                                                handleClose={handleInstructionModalClose}
                                                                instruction={data.instructions?.en}
                                                            />
                                                        : null
                                                    }
                                                </Grid>
                                                <Grid item xl={4} lg={4} md={4} sm={4} xs={6} className={styles.centerAndEndPlacement}>
                                                    <span className={styles.viewInText}>View in</span>
                                                    <span className={styles.langText}>English</span>
                                                </Grid>
                                                <Grid item xl={5} lg={5} md={5} sm={5} xs={6} className={styles.centerAndEndPlacement}>
                                                    <Image src={TestModeTimer} className={styles.calcIcon} alt="screenModeIcon"/>
                                                    <CountdownTimer
                                                        countdownTime={data.time}
                                                        handleTimeChange={handleTimeChange}
                                                    />
                                                    {
                                                        showCustomTextModal ?
                                                            <CustomText
                                                                open={showCustomTextModal}
                                                                handleClose={handleTimeUpModalClose}
                                                                text={'Time\'s Up!!'}
                                                            />
                                                        : null
                                                    }
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>

                                <Grid container className={styles.paperContainer}>
                                    {/* Paper Questions */}
                                    <Grid item xl={9} lg={7} sm={12} md={12} xs={12} className={`${styles.testModeQuestionSectionLeft} ${scrollBarStyles.myCustomScrollbar}`}>
                                        <Grid container>
                                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.singleQuestion} id={`question-${1}`}>
                                                <Grid container>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                        <Question
                                                            question={currentQuestion}
                                                            index={currentIndex}
                                                        />
                                                    </Grid>
                                                </Grid>

                                                <Grid container>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                        <Choices
                                                            question={currentQuestion}
                                                            userActionData={userActionData}
                                                            index={currentIndex}
                                                            handleMCQAnswerSelect={handleMCQAnswerSelect}
                                                            handleMSQAnswerSelect={handleMSQAnswerSelect}
                                                            mode={"test"}
                                                        />
                                                    </Grid>

                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                        <AnswerInput
                                                            question={currentQuestion}
                                                            userActionData={userActionData}
                                                            handleAnswerValue={handleAnswerValue}
                                                            mode={"test"}
                                                        />
                                                    </Grid>
                                                </Grid>

                                                <Grid container>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                        <Grid container>
                                                            <Grid item xl={6} lg={8} md={6} sm={8} xs={8}>
                                                                <Grid container>
                                                                    <Button
                                                                        className={styles.markForReviewBtn}
                                                                        onClick={() => markForReview()}
                                                                    >
                                                                        Mark for review
                                                                    </Button>
                                                                    <Button
                                                                        className={styles.clearResBtn}
                                                                        onClick={() => clearResponse()}
                                                                    >
                                                                        Clear Response
                                                                    </Button>
                                                                </Grid>
                                                            </Grid>
                                                            <Grid item xl={6} lg={4} md={6} sm={4} xs={4} className={styles.saveAndNextBtnContainer}>
                                                                <Button
                                                                    className={styles.saveAndNextBtn}
                                                                    onClick={() => saveAndNext()}
                                                                >
                                                                    Save & Next
                                                                </Button>
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Grid>

                                    {/* Calc and Paper Section : START */}
                                    <Grid item xl={3} lg={5} md={6} sm={7} xs={12} className={styles.fixedCalcAndSectionContainer}>
                                        <Grid container className={styles.fixedCalcAndSectionInnerContainer}>
                                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                <Grid container>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.insightContainer}>
                                                        <Grid container style={{ marginBottom : "30px"}}>
                                                            <Grid item xl={4} lg={4} sm={4} md={4} xs={4}>
                                                                <div className={styles.answeredTotal}>
                                                                    {userActionData.filter((action) => action.status === "answered").length}
                                                                </div>
                                                                <span>Answered</span>
                                                            </Grid>
                                                            <Grid item xl={4} lg={4} sm={4} md={4} xs={4}>
                                                                <div className={styles.markedTotal}>
                                                                    {userActionData.filter((action) => action.status === "marked").length}
                                                                </div>
                                                                <span>Marked</span>
                                                            </Grid>
                                                            <Grid item xl={4} lg={4} sm={4} md={4} xs={4}>
                                                                <div className={styles.notVisitedTotal}>
                                                                    {userActionData.filter((action) => action.status === "notVisited").length}
                                                                </div>
                                                                <span>Not visited</span>
                                                            </Grid>
                                                        </Grid>
                                                        <Grid container>
                                                            <Grid item xl={7} lg={7} sm={7} md={7} xs={8}>
                                                                <div className={styles.markedAndAnsweredTotal}>
                                                                    {userActionData.filter((action) => action.status === "markedAndAnswered").length}
                                                                </div>
                                                                <span>Marked and answered</span>
                                                            </Grid>
                                                            <Grid item xl={5} lg={5} sm={5} md={5} xs={4}>
                                                                <div className={styles.notAnsweredTotal}>
                                                                    {userActionData.filter((action) => action.status === "notAnswered").length}
                                                                </div>
                                                                <span>Not answered</span>
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                                
                                                <Grid container className={showCalculator ? styles.showCalc : styles.hideCalc}>
                                                    <Draggable
                                                        allowAnyClick={true}
                                                        axis="both"
                                                        handle=".handle"
                                                        defaultPosition={{x: 0, y: 0}}
                                                        position={null}
                                                        grid={[25, 25]}
                                                        scale={1}
                                                    >
                                                        <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={`${styles.scientificCalcContainer} ${"handle"}`}>
                                                            <ScientificCalculator
                                                                handleClose={handleCalcClose}
                                                            />
                                                        </Grid>
                                                    </Draggable>
                                                </Grid>

                                                <Grid container className={`${styles.sectionsMainContainer} ${scrollBarStyles.myCustomScrollbar}`}>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.sectionContainer}>
                                                        <span>Sections</span>
                                                    </Grid>
                                                    <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                        {
                                                            data?.sections?.map((section,sectionId) => (
                                                                <Accordion
                                                                    key={section._id}
                                                                    expanded={expanded === `panel${sectionId}`}
                                                                    onChange={handleAccordionChange(`panel${sectionId}`,sectionId)}
                                                                    className={styles.accordionMain}
                                                                >
                                                                    <AccordionSummary
                                                                        aria-controls={`panel${sectionId}d-content`}
                                                                        id={`panel${sectionId}d-header`}
                                                                        className={activeSection === sectionId ? styles.activeAccordionSummary : ""}
                                                                    >
                                                                        <Typography
                                                                            className={activeSection === sectionId ? styles.activeAccordionTitle : styles.accordionTitle}
                                                                        >
                                                                            {section.name}
                                                                        </Typography>
                                                                    </AccordionSummary>
                                                                    <AccordionDetails>
                                                                        <Grid container>
                                                                            {
                                                                                section?.questions?.map((question,questionId) => (
                                                                                    <>
                                                                                        {(questionId % 4 === 0) && (
                                                                                            <Grid container className={styles.questionIndexContainer} key={questionId}>
                                                                                                {/* Add Grid container for every 5th index */}
                                                                                            </Grid>
                                                                                        )}
                                                                                        <Grid item xl={3} lg={3} sm={3} md={3} xs={3}>
                                                                                            <div
                                                                                                className={`${userActionData.find(item => item.id === question._id)?.status !== "" ?
                                                                                                    userActionData.find(item => item.id === question._id)?.status === "answered" ?
                                                                                                        styles.answeredIndexBtn
                                                                                                    :
                                                                                                    userActionData.find(item => item.id === question._id)?.status === "marked" ?
                                                                                                        styles.markedIndexBtn
                                                                                                    :
                                                                                                    userActionData.find(item => item.id === question._id)?.status === "markedAndAnswered" ?
                                                                                                        styles.markedAndAnsweredIndexBtn
                                                                                                    :
                                                                                                    userActionData.find(item => item.id === question._id)?.status === "notAnswered" ?
                                                                                                        styles.notAnsweredIndexBtn
                                                                                                    :
                                                                                                    userActionData.find(item => item.id === question._id)?.status === "notVisited" &&
                                                                                                        styles.notVisitedIndexBtn
                                                                                                    : styles.indexBtn}
                                                                                                    ${styles.indexBtnContainer}`
                                                                                                }
                                                                                                onClick={() => handleQuestionIndexClick(sectionId,questionId,question._id)}
                                                                                            >
                                                                                                <span
                                                                                                    key={question._id}
                                                                                                >
                                                                                                    {questionId + 1}
                                                                                                </span>
                                                                                            </div>
                                                                                        </Grid>
                                                                                    </>
                                                                                ))
                                                                            }
                                                                        </Grid>
                                                                    </AccordionDetails>
                                                                </Accordion>
                                                            ))
                                                        }
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                        
                                        <Grid container>
                                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12}>
                                                <Button
                                                    className={styles.questionPaperBtn}
                                                    onClick={() => setShowQuestionPaper(true)}
                                                >
                                                    Question Paper
                                                </Button>
                                            </Grid>
                                            <Grid item xl={12} lg={12} sm={12} md={12} xs={12} className={styles.submitPaperBtnContainer}>
                                                <Button
                                                    className={`${styles.submitPaperBtn} ${"handle"}`}
                                                    onClick={() => handlePaperSubmit()}
                                                    disabled={submitTestLoader}
                                                >
                                                    {submitTestLoader ?
                                                        <CircularProgress
                                                            sx={{ color: 'var(--white)' }}
                                                            size={25}
                                                        /> : 'Submit Paper'
                                                    }
                                                </Button>                                                
                                            </Grid>
                                            {
                                                showQuestionPaper ?
                                                    <QuestionPaper
                                                        open={showQuestionPaper}
                                                        handleClose={handleModalClose}
                                                        data={data.sections}
                                                    />
                                                : null
                                            }
                                            {
                                                showSubmitTestConfirmationModal ?
                                                    <SubmiTestConfirmation
                                                        open={showSubmitTestConfirmationModal}
                                                        handleClose={handleConfirmationModalClose}
                                                        remainingTime={remainingTime}
                                                        handleSubmit={handleSectionTackle}
                                                    />
                                                :
                                                    null
                                            }
                                        </Grid>
                                    </Grid>
                                    {/* Calc and Paper Section : END */}
                                </Grid>
                            </Grid>
                    }
                </Grid>
            </section>
        </>
    )
}

export default TestMode;

export async function getServerSideProps(context) {
    const { req } = context;
    const session = await getSession({ req });
    
    if(!session) {
        return {
            redirect: { destination: "/" },
        };
    }
      
    return {
        props: {
            session
        }
    }
}