import { facetHelper } from "../helpers/paginationHelper";
var ObjectId = require("mongodb").ObjectID;

export const getAllPapersForStudent = async (Model,data) => {
	try{
		let pipeline = [];
		
		// adding query into the pipeline array
        pipeline.push({
			$match: {
            	$expr: {
					$and: [
						{
							$eq: ['$department', data.department]
						},
						{
							$eq: ['$exam', data.exam]
						},
						{
							$eq: [ "$display", true ]
						}
					] 
                }
			},
		});

		pipeline.push({
			$project: {
				'instructions': 1, 
				'display': 1, 
				'lock': 1, 
				'publish': 1, 
				'name': 1, 
				'department': 1,
				'exam': 1
			}
		})
		
		const result = await Model.aggregate(pipeline);
		console.log(result,"resultData");

		// Reverse the data using reverse() method
		const reversedResult = result.reverse();

		return reversedResult;
	}catch(error){
		console.log('error In FINDPAPERSFORSTUDENT ', error);
		return false;
	}
}

export const getSubjectWisePapersForStudent = async (Model,data) => {
	try{
		let pipeline = [];
		
		// adding query into the pipeline array
        pipeline.push({
			$match: {
            	$expr: {    
                    $eq: [ "$_id", data.department ],
                }
			},
		});

        pipeline.push({
            $lookup: {
                from: "subjects",
                localField: "subjects",
                foreignField: "_id",
				pipeline: [
					{
						$project: {
							'code': 1, 
							'title': 1,
							'lock' : 1
						}
					}
				],
                as: "subjects"
            }
        });
		
		const result = await Model.aggregate(pipeline);
		console.log(result,"resultData");
		return result;
	}catch(error){
		console.log('error In FINDPAPERSFORSTUDENT ', error);
		return false;
	}
}


export const getSubjectWiseQuestionsForStudent = async (Model,user,data) => {
	try{
		let pipeline = [];
		
		// adding query into the pipeline array
        pipeline.push({
			$match: {
                $expr: {
                    $and: [
                        {
                            $eq: ['$department', ObjectId(user.department)]
                        },
                        {
                            $eq: [ "$exam", ObjectId(user.exam) ],
                        },
                        {
                            $eq: [ "$subject", ObjectId(data.id) ],
                        },
						{
                            $eq: [ "$year", data.year ],
                        }
                    ]
                }
            },
		});
		
		const result = await Model.aggregate(pipeline);
		console.log(result,"resultData");
		return result;
	}catch(error){
		console.log('error In FINDSUBJECTWISEQUESTIONS ', error);
		return false;
	}
}