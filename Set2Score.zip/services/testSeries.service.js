var ObjectId = require("mongodb").ObjectID;

export const getFullLengthTestSeries = async (Model,data) => {
	try{
		let pipeline = [];
		
		// adding query into the pipeline array
        pipeline.push({
			$match: {
            	$expr: {
					$and: [
						{
							$eq: ['$department', data.department.valueOf()]
						},
						{
							$eq: ['$exam', data.exam.valueOf()]
						},
                        {
							$eq: ['$mode', "full"]
                        },
						{
							$eq: [ "$display", true ]
						}
					] 
                }
			},
		});

		pipeline.push({
			$project: {
				'display': 1, 
				'lock': 1, 
				'publish': 1, 
				'name': 1, 
				'department': 1,
				'exam': 1,
                'time': 1,
                'releaseDate': 1,
                'totalQuestions': { $sum: { $map: { input: '$sections', as: 'section', in: { $size: '$$section.questions' } } } }
			}
		})

        pipeline.push({ $sort: { releaseDate: 1 } });
		
		const result = await Model.aggregate(pipeline);
		console.log(result,"resultData");
		return result;
	}catch(error){
		console.log('error In FINDFULLLENGTHTESTSERIES ', error);
		return false;
	}
}

export const getSubjectWiseTestSeries = async (Model,data) => {
	try{
		let pipeline = [];
		
		// adding query into the pipeline array
        pipeline.push({
			$match: {
            	$expr: {
					$and: [
						{
							$eq: ['$department', data.department.valueOf()]
						},
						{
							$eq: ['$exam', data.exam.valueOf()]
						},
                        {
							$eq: ['$mode', "subject"]
                        },
						{
							$eq: [ "$display", true ]
						}
					] 
                }
			},
		});

		pipeline.push({
			$project: {
				'display': 1, 
				'lock': 1, 
				'publish': 1, 
				'name': 1, 
				'department': 1,
				'exam': 1,
                'time': 1,
                'releaseDate': 1,
                'totalQuestions': { $sum: { $map: { input: '$sections', as: 'section', in: { $size: '$$section.questions' } } } }
			}
		})

        pipeline.push({ $sort: { releaseDate: 1 } });
		
		const result = await Model.aggregate(pipeline);
		console.log(result,"resultData");
		return result;
	}catch(error){
		console.log('error In FINDSUBJECTWISETESTSERIES ', error);
		return false;
	}
}