import { validationMessageKey } from '../helpers/helper';
const Joi = require('joi');

export const submitTestResultValidation = async (req) => {
    const schema = Joi.object({
        test: Joi.string().min(24).max(24).required(),
        department: Joi.string().min(24).max(24).required(),
        exam: Joi.string().min(24).max(24).required(),
        mode: Joi.string().required(),
        title: Joi.string().required(),
        totalQuestions: Joi.number().required(),
        answeredQuestions: Joi.number().required(),
        wrongAnswers: Joi.number().required(),
        marksExpected: Joi.number().required(),
        marksObtained: Joi.number().required(),
        marksSubtracted: Joi.string().required(),
        scored: Joi.string().required(),
    }).unknown(true);

    const { error } = schema.validate(req);

    if(error) {
        return validationMessageKey("validation", error);
    }

    return null;
}